class AppBar extends HTMLElement {
 
    constructor() {
        super();
        this.shadowDOM = this.attachShadow({mode: "open"});
    }
  
    connectedCallback(){
        this.render();
    }
  
    render() {
        this.shadowDOM.innerHTML = `
        <style>
            * {
                margin: 0;
                padding: 0;
                box-sizing: border-box;
                color: rgb(155, 58, 2);
                font-size: 80px;
                padding: 105px;
                text-align: center;
                font-family: 'Indie Flower', cursive;
            }
            :host {
                display: block;
                width: 100%;
                color: white;
                box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
            }
            h2 {
                padding: 16px;
            }
        </style>
        <h2>Ella Food</h2>`;
    }
 }

  
 customElements.define("app-bar", AppBar);